/* global React, ExploreData */
const { useState, useMemo } = React;
const { TOOL_LABELS } = ExploreData;

const TOOLS = [
  { value: "cursor", label: "Cursor" },
  { value: "claude-code", label: "Claude Code" },
  { value: "copilot", label: "Copilot" },
  { value: "chatgpt", label: "ChatGPT" },
  { value: "aider", label: "Aider" },
  { value: "other", label: "Other" },
];
const TASKS = [
  { value: "rules", label: "Rules / system" },
  { value: "refactor", label: "Refactor" },
  { value: "scaffold", label: "Scaffold" },
  { value: "debug", label: "Debug" },
  { value: "test", label: "Test" },
  { value: "review", label: "Code review" },
  { value: "explain", label: "Explain" },
  { value: "other", label: "Other" },
];

const TEMPLATES = [
  { id: "rules", label: "Rules file", icon: "▣",
    title: "CLAUDE.md — project rules",
    body: "You are working in this project. Before editing any file:\n1. Read the relevant README\n2. Check existing patterns in the codebase\n3. Run the linter when done\n\nNever make cross-package changes without asking first.",
    tool: "claude-code", taskType: "rules" },
  { id: "refactor", label: "Refactor", icon: "↻",
    title: "Refactor pass",
    body: "Review this file and identify any unused variables, dead code branches, or functions that are never called. Explain each removal and ensure nothing is needed for side effects.",
    tool: "cursor", taskType: "refactor" },
  { id: "review", label: "Code review", icon: "✓",
    title: "Senior engineer review",
    body: "Act as a senior engineer reviewing this PR. Look for:\n- Bugs and edge cases\n- Performance issues\n- Naming clarity\n- Test coverage gaps\n\nBe direct. No fluff.",
    tool: "chatgpt", taskType: "review" },
  { id: "blank", label: "Blank", icon: "+",
    title: "", body: "", tool: "cursor", taskType: "rules" },
];

const STACK_SUGGEST = ["typescript", "react", "next.js", "node", "python", "tailwind", "rust", "postgres", "jest", "monorepo"];

const ArrowL = () => <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M8 3L4 7l4 4M4 7h9" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const Globe = () => <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="4.5" stroke="currentColor"/><path d="M6 1.5c1.5 1.5 1.5 7.5 0 9M6 1.5c-1.5 1.5-1.5 7.5 0 9M1.5 6h9" stroke="currentColor"/></svg>;
const Lock = () => <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><rect x="2.5" y="5" width="7" height="5.5" rx="1" stroke="currentColor"/><path d="M4 5V3.5a2 2 0 1 1 4 0V5" stroke="currentColor" fill="none"/></svg>;
const Check = () => <svg width="10" height="10" viewBox="0 0 12 12" fill="none"><path d="M2 6.5l3 3 5-7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/></svg>;
const X = () => <svg width="9" height="9" viewBox="0 0 12 12" fill="none"><path d="M3 3l6 6M9 3l-6 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>;
const Sparkle = () => <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M6 1L7 5L11 6L7 7L6 11L5 7L1 6L5 5L6 1Z" fill="currentColor"/></svg>;

function ToolTag({ tool, taskType }) {
  return (
    <span className={`tool-tag tool-tag-${tool}`}>
      {TOOL_LABELS[tool] || tool}
      <span style={{ opacity: 0.6, fontWeight: 300 }}>/ {taskType}</span>
    </span>
  );
}

/* ─── A. Two-column with live preview ─── */
function NewPromptA() {
  const [tpl, setTpl] = useState("blank");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [desc, setDesc] = useState("");
  const [tool, setTool] = useState("cursor");
  const [task, setTask] = useState("rules");
  const [stack, setStack] = useState([]);
  const [stackInput, setStackInput] = useState("");
  const [isPublic, setIsPublic] = useState(false);

  function applyTpl(t) {
    setTpl(t.id);
    setTitle(t.title); setBody(t.body);
    setTool(t.tool); setTask(t.taskType);
  }
  function addStack(s) {
    s = s.trim().toLowerCase();
    if (s && !stack.includes(s)) setStack([...stack, s]);
    setStackInput("");
  }
  function onStackKey(e) {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addStack(stackInput);
    } else if (e.key === "Backspace" && !stackInput && stack.length) {
      setStack(stack.slice(0, -1));
    }
  }

  const charCount = body.length;
  const isLong = charCount > 8000;

  return (
    <div className="np-shell">
      <header className="np-header">
        <button className="np-back"><ArrowL /> Back to library</button>
        <div className="np-header-r">
          <span className="np-saved"><Check /> Draft autosaved · just now</span>
          <button className="np-btn-secondary">Save as draft</button>
          <button className="np-btn-primary">{isPublic ? "Publish prompt" : "Save prompt"}</button>
        </div>
      </header>

      <div className="np-title-row">
        <span className="section-tag">New prompt</span>
        <h1 className="np-h1">Add to your library</h1>
      </div>

      <div className="np-tpl-row">
        <span className="np-tpl-label">Start from</span>
        {TEMPLATES.map(t => (
          <button key={t.id} className={`np-tpl ${tpl === t.id ? "active" : ""}`} onClick={() => applyTpl(t)}>
            <span className="np-tpl-icon">{t.icon}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      <div className="np-grid">
        <div className="np-form">
          <div className="np-field">
            <label className="np-label">
              <span>Title</span>
              <span className="np-hint">{title.length}/200</span>
            </label>
            <input className="np-input" value={title} onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Cursor rules for Next.js App Router" maxLength={200} />
          </div>

          <div className="np-field">
            <label className="np-label">
              <span>Prompt</span>
              <span className="np-hint" style={{ color: isLong ? "var(--lp-red)" : "var(--lp-text-dim)" }}>
                {charCount.toLocaleString()} / 20,000 chars
              </span>
            </label>
            <div className="np-code-wrap">
              <div className="np-code-bar">
                <span className="np-code-tag">prompt.md</span>
                <div className="np-code-bar-r">
                  <button className="np-code-btn">Wrap</button>
                  <button className="np-code-btn">Paste</button>
                </div>
              </div>
              <textarea className="np-code" rows={16} value={body} onChange={e => setBody(e.target.value)}
                placeholder="Paste your prompt, rules file, or context block here…" />
            </div>
          </div>

          <div className="np-row-2">
            <div className="np-field">
              <label className="np-label"><span>Tool</span></label>
              <div className="np-segment">
                {TOOLS.map(t => (
                  <button key={t.value} className={`np-seg ${tool === t.value ? "active" : ""}`} onClick={() => setTool(t.value)}>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="np-field">
              <label className="np-label"><span>Task type</span></label>
              <div className="np-segment">
                {TASKS.map(t => (
                  <button key={t.value} className={`np-seg ${task === t.value ? "active" : ""}`} onClick={() => setTask(t.value)}>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="np-field">
            <label className="np-label">
              <span>Description</span>
              <span className="np-hint">Optional · helps others know when to use it</span>
            </label>
            <textarea className="np-input np-textarea" rows={2} value={desc} onChange={e => setDesc(e.target.value)}
              placeholder="Why this works, when to use it…" />
          </div>

          <div className="np-field">
            <label className="np-label">
              <span>Stack</span>
              <span className="np-hint">Press Enter or , to add</span>
            </label>
            <div className="np-tokens" onClick={() => document.getElementById("np-stack-input").focus()}>
              {stack.map(s => (
                <span key={s} className="np-token">
                  {s}
                  <button onClick={(e) => { e.stopPropagation(); setStack(stack.filter(x => x !== s)); }}><X /></button>
                </span>
              ))}
              <input id="np-stack-input" className="np-token-input"
                value={stackInput} onChange={e => setStackInput(e.target.value)}
                onKeyDown={onStackKey} placeholder={stack.length ? "" : "nextjs, typescript, tailwind"} />
            </div>
            <div className="np-suggest">
              {STACK_SUGGEST.filter(s => !stack.includes(s)).slice(0, 6).map(s => (
                <button key={s} className="np-suggest-chip" onClick={() => addStack(s)}>+ {s}</button>
              ))}
            </div>
          </div>

          <div className="np-publish">
            <div>
              <div className="np-publish-title">
                {isPublic ? <><Globe /> Public on Explore</> : <><Lock /> Private to you</>}
              </div>
              <p className="np-publish-desc">
                {isPublic
                  ? "Anyone can find, copy, and fork this prompt. You'll see upvote and copy counts."
                  : "Only you can see this prompt. You can publish it later from your library."}
              </p>
            </div>
            <button className={`np-switch ${isPublic ? "on" : ""}`} onClick={() => setIsPublic(!isPublic)}>
              <span className="np-switch-thumb" />
            </button>
          </div>
        </div>

        <aside className="np-preview">
          <div className="np-preview-head">
            <Sparkle /> <span>Live preview</span>
          </div>

          <article className="np-card">
            <div className="np-card-head">
              <ToolTag tool={tool} taskType={task} />
              <span className={`np-vis ${isPublic ? "public" : "private"}`}>
                {isPublic ? <><Globe /> Public</> : <><Lock /> Private</>}
              </span>
            </div>
            <h3 className="np-card-title">{title || <span className="np-placeholder">Untitled prompt</span>}</h3>
            {desc ? <p className="np-card-desc">{desc}</p> : <p className="np-card-desc np-placeholder">Description appears here…</p>}
            <pre className="np-card-body">{body || <span className="np-placeholder">Your prompt body shows here as a 3-line snippet.</span>}</pre>
            <div className="np-card-stack">
              {stack.length ? stack.slice(0, 4).map(s => <span key={s} className="ex-stack-chip">{s}</span>) :
                <span className="np-placeholder" style={{ fontFamily: "var(--font-mono)", fontSize: 11 }}>+ stack chips</span>}
              {stack.length > 4 && <span className="ex-stack-more">+{stack.length - 4}</span>}
            </div>
            <div className="np-card-foot">
              <span className="np-author">
                <span className="np-avatar">W</span>
                <span>Wendy O. · just now</span>
              </span>
              <span className="np-card-actions">↑ 0 · ⎘ 0</span>
            </div>
          </article>

          <div className="np-tips">
            <div className="np-tips-h">Tips for a great prompt</div>
            <ul>
              <li>Lead with the role or context ("You are a senior…")</li>
              <li>Number your constraints — models obey lists better</li>
              <li>End with the format you want back</li>
              <li>Keep it scannable: under 500 words is usually enough</li>
            </ul>
          </div>

          <div className="np-shortcut">
            <kbd>⌘</kbd><kbd>S</kbd> Save · <kbd>⌘</kbd><kbd>Enter</kbd> Publish
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ─── B. Editor-first single-column ─── */
function NewPromptB() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [tool, setTool] = useState("cursor");
  const [task, setTask] = useState("rules");
  const [stack, setStack] = useState(["typescript"]);
  const [stackInput, setStackInput] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [desc, setDesc] = useState("");
  const [showMeta, setShowMeta] = useState(true);

  function addStack(s) {
    s = s.trim().toLowerCase();
    if (s && !stack.includes(s)) setStack([...stack, s]);
    setStackInput("");
  }
  function onStackKey(e) {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addStack(stackInput); }
    else if (e.key === "Backspace" && !stackInput && stack.length) setStack(stack.slice(0, -1));
  }

  return (
    <div className="np-shell">
      <header className="np-header np-header-tight">
        <button className="np-back"><ArrowL /> Library</button>
        <div className="np-breadcrumb">
          <span className="np-saved"><Check /> Autosaved</span>
          <button className="np-btn-secondary">Cancel</button>
          <button className="np-btn-primary">{isPublic ? "Publish" : "Save prompt"}</button>
        </div>
      </header>

      <div className="np-editor">
        <input
          className="np-title-input"
          placeholder="Untitled prompt"
          value={title} onChange={e => setTitle(e.target.value)}
        />

        <div className="np-meta-bar">
          <ToolTag tool={tool} taskType={task} />
          <select className="ex-select" value={tool} onChange={e => setTool(e.target.value)}>
            {TOOLS.map(t => <option key={t.value} value={t.value}>Tool: {t.label}</option>)}
          </select>
          <select className="ex-select" value={task} onChange={e => setTask(e.target.value)}>
            {TASKS.map(t => <option key={t.value} value={t.value}>Task: {t.label}</option>)}
          </select>
          <div className="np-tokens np-tokens-inline" onClick={() => document.getElementById("npb-stack").focus()}>
            {stack.map(s => (
              <span key={s} className="np-token">
                {s}<button onClick={(e) => { e.stopPropagation(); setStack(stack.filter(x => x !== s)); }}><X /></button>
              </span>
            ))}
            <input id="npb-stack" className="np-token-input" placeholder={stack.length ? "" : "+ stack"}
              value={stackInput} onChange={e => setStackInput(e.target.value)} onKeyDown={onStackKey} />
          </div>
        </div>

        <div className="np-code-wrap np-code-tall">
          <div className="np-code-bar">
            <span className="np-code-tag">prompt.md · {body.length.toLocaleString()} chars</span>
            <div className="np-code-bar-r">
              <button className="np-code-btn">Preview</button>
              <button className="np-code-btn">Format</button>
            </div>
          </div>
          <textarea className="np-code np-code-tall-ta" rows={20} value={body} onChange={e => setBody(e.target.value)}
            placeholder="# Your prompt&#10;&#10;Paste your prompt, rules file, or context block here…" />
        </div>

        <button className="np-meta-toggle" onClick={() => setShowMeta(!showMeta)}>
          {showMeta ? "▾" : "▸"} Description, sharing & options
        </button>

        {showMeta && (
          <div className="np-meta-grid">
            <div className="np-field">
              <label className="np-label"><span>Description</span><span className="np-hint">Optional</span></label>
              <textarea className="np-input np-textarea" rows={2} value={desc} onChange={e => setDesc(e.target.value)}
                placeholder="Why this works, when to use it…" />
            </div>
            <div className="np-publish np-publish-compact">
              <div>
                <div className="np-publish-title">
                  {isPublic ? <><Globe /> Public on Explore</> : <><Lock /> Private to you</>}
                </div>
                <p className="np-publish-desc">
                  {isPublic ? "Anyone can find, copy and fork this." : "Only you can see this."}
                </p>
              </div>
              <button className={`np-switch ${isPublic ? "on" : ""}`} onClick={() => setIsPublic(!isPublic)}>
                <span className="np-switch-thumb" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── C. Stepper / wizard ─── */
function NewPromptC() {
  const [step, setStep] = useState(0);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [tool, setTool] = useState("");
  const [task, setTask] = useState("");
  const [stack, setStack] = useState([]);
  const [stackInput, setStackInput] = useState("");
  const [desc, setDesc] = useState("");
  const [isPublic, setIsPublic] = useState(false);

  function addStack(s) {
    s = s.trim().toLowerCase();
    if (s && !stack.includes(s)) setStack([...stack, s]);
    setStackInput("");
  }
  function onStackKey(e) {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); addStack(stackInput); }
  }

  const steps = ["Paste", "Categorize", "Share"];
  const canNext =
    (step === 0 && body.trim().length > 0 && title.trim().length > 0) ||
    (step === 1 && tool && task) ||
    (step === 2);

  return (
    <div className="np-shell">
      <header className="np-header">
        <button className="np-back"><ArrowL /> Back to library</button>
        <div className="np-stepper">
          {steps.map((s, i) => (
            <div key={s} className={`np-step ${i === step ? "current" : i < step ? "done" : ""}`}>
              <span className="np-step-n">{i < step ? <Check /> : i + 1}</span>
              <span>{s}</span>
              {i < steps.length - 1 && <span className="np-step-line" />}
            </div>
          ))}
        </div>
      </header>

      <div className="np-wizard">
        {step === 0 && (
          <>
            <span className="section-tag">Step 1 of 3</span>
            <h2 className="np-wiz-h">Paste your prompt.</h2>
            <p className="np-wiz-sub">Title it however you'll remember it. Body is the actual text you'll copy back later.</p>

            <div className="np-field">
              <label className="np-label"><span>Title</span></label>
              <input className="np-input np-input-lg" value={title} onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Cursor rules for Next.js App Router" autoFocus />
            </div>
            <div className="np-field">
              <label className="np-label"><span>Prompt body</span><span className="np-hint">{body.length.toLocaleString()} chars</span></label>
              <div className="np-code-wrap">
                <div className="np-code-bar">
                  <span className="np-code-tag">prompt.md</span>
                </div>
                <textarea className="np-code" rows={14} value={body} onChange={e => setBody(e.target.value)}
                  placeholder="Paste here…" />
              </div>
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <span className="section-tag">Step 2 of 3</span>
            <h2 className="np-wiz-h">Help people find it.</h2>
            <p className="np-wiz-sub">Tag the tool, task type, and stack. Used by Explore filters.</p>

            <div className="np-field">
              <label className="np-label"><span>Which tool is this for?</span></label>
              <div className="np-pickgrid">
                {TOOLS.map(t => (
                  <button key={t.value} className={`np-pick ${tool === t.value ? "active" : ""}`} onClick={() => setTool(t.value)}>
                    <span className={`np-pick-dot tool-tag tool-tag-${t.value}`} style={{ padding: "4px 8px" }}>{t.label.charAt(0)}</span>
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="np-field">
              <label className="np-label"><span>What kind of task?</span></label>
              <div className="np-pickgrid np-pickgrid-narrow">
                {TASKS.map(t => (
                  <button key={t.value} className={`np-pick np-pick-sm ${task === t.value ? "active" : ""}`} onClick={() => setTask(t.value)}>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="np-field">
              <label className="np-label"><span>Stack</span><span className="np-hint">Press Enter or , to add</span></label>
              <div className="np-tokens" onClick={() => document.getElementById("npc-stack").focus()}>
                {stack.map(s => (
                  <span key={s} className="np-token">
                    {s}<button onClick={(e) => { e.stopPropagation(); setStack(stack.filter(x => x !== s)); }}><X /></button>
                  </span>
                ))}
                <input id="npc-stack" className="np-token-input" placeholder={stack.length ? "" : "typescript, react, tailwind"}
                  value={stackInput} onChange={e => setStackInput(e.target.value)} onKeyDown={onStackKey} />
              </div>
              <div className="np-suggest">
                {STACK_SUGGEST.filter(s => !stack.includes(s)).slice(0, 6).map(s => (
                  <button key={s} className="np-suggest-chip" onClick={() => addStack(s)}>+ {s}</button>
                ))}
              </div>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <span className="section-tag">Step 3 of 3</span>
            <h2 className="np-wiz-h">Keep it private, or share it?</h2>
            <p className="np-wiz-sub">You can change this any time. Add a description so others know when to use it.</p>

            <div className="np-field">
              <label className="np-label"><span>Description</span><span className="np-hint">Optional</span></label>
              <textarea className="np-input np-textarea" rows={3} value={desc} onChange={e => setDesc(e.target.value)}
                placeholder="Why this works, when to use it…" />
            </div>

            <div className="np-share-grid">
              <button className={`np-share ${!isPublic ? "active" : ""}`} onClick={() => setIsPublic(false)}>
                <Lock />
                <div className="np-share-h">Private</div>
                <p>Only you can see this. Default — change later from your library.</p>
              </button>
              <button className={`np-share ${isPublic ? "active" : ""}`} onClick={() => setIsPublic(true)}>
                <Globe />
                <div className="np-share-h">Public on Explore</div>
                <p>Anyone can find, copy, and fork it. You'll see upvote and copy counts.</p>
              </button>
            </div>

            <div className="np-summary">
              <div className="np-summary-h">Ready to save</div>
              <ul>
                <li><b>{title || "Untitled prompt"}</b></li>
                <li>{TOOL_LABELS[tool] || "—"} · {task || "—"}</li>
                <li>{stack.length ? stack.join(", ") : "no stack tags"}</li>
                <li>{isPublic ? "Public on Explore" : "Private to you"}</li>
              </ul>
            </div>
          </>
        )}

        <div className="np-wiz-foot">
          {step > 0 && <button className="np-btn-secondary" onClick={() => setStep(step - 1)}>← Back</button>}
          <div style={{ flex: 1 }} />
          {step < 2 ? (
            <button className="np-btn-primary" onClick={() => setStep(step + 1)} disabled={!canNext}>Continue →</button>
          ) : (
            <button className="np-btn-primary">{isPublic ? "Publish prompt" : "Save to library"}</button>
          )}
        </div>
      </div>
    </div>
  );
}

window.NewPromptVariations = { NewPromptA, NewPromptB, NewPromptC };
