/* global React, ExploreData */
const { useState, useMemo } = React;
const { TOOL_LABELS, SAMPLE_PROMPTS } = ExploreData;

// Library = personal prompts (mix of public + private)
const MY_PROMPTS = [
  { ...SAMPLE_PROMPTS[0], _id: "m1", isPublic: true,  upvoteCount: 1204, copyCount: 4890, createdAt: "Jan 12" },
  { ...SAMPLE_PROMPTS[1], _id: "m2", isPublic: true,  upvoteCount: 991,  copyCount: 3105, createdAt: "Jan 10" },
  { ...SAMPLE_PROMPTS[2], _id: "m3", isPublic: false, upvoteCount: 0,    copyCount: 0,    createdAt: "Jan 8",
    title: "Personal: extract types from JSON",
    description: "Quick paste-in for converting API responses into typed interfaces." },
  { ...SAMPLE_PROMPTS[7], _id: "m4", isPublic: true,  upvoteCount: 521,  copyCount: 1644, createdAt: "Dec 28" },
  { ...SAMPLE_PROMPTS[3], _id: "m5", isPublic: false, upvoteCount: 0,    copyCount: 0,    createdAt: "Dec 22",
    title: "WIP: My security review prompt",
    description: "Still iterating on this — too verbose right now." },
  { ...SAMPLE_PROMPTS[5], _id: "m6", isPublic: false, upvoteCount: 0,    copyCount: 0,    createdAt: "Dec 18",
    title: "Storybook story scaffold",
    description: "Generates a story file matching our team's MDX format." },
  { ...SAMPLE_PROMPTS[6], _id: "m7", isPublic: true,  upvoteCount: 89,   copyCount: 234,  createdAt: "Dec 14" },
  { ...SAMPLE_PROMPTS[8], _id: "m8", isPublic: false, upvoteCount: 0,    copyCount: 0,    createdAt: "Dec 4",
    title: "My git commit style",
    description: "Forked from Bea N's, customized for my workflow." },
];

const Lock = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <rect x="2.5" y="5" width="7" height="5.5" rx="1" stroke="currentColor"/>
    <path d="M4 5V3.5a2 2 0 1 1 4 0V5" stroke="currentColor" fill="none"/>
  </svg>
);
const Globe = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <circle cx="6" cy="6" r="4.5" stroke="currentColor"/>
    <path d="M6 1.5c1.5 1.5 1.5 7.5 0 9M6 1.5c-1.5 1.5-1.5 7.5 0 9M1.5 6h9" stroke="currentColor"/>
  </svg>
);
const Pencil = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M8.5 1.5l2 2-6 6-2.5.5.5-2.5 6-6z" stroke="currentColor"/>
  </svg>
);
const Trash = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M2 3h8M4.5 1.5h3M3 3l.5 7.5h5L9 3M5 5v4M7 5v4" stroke="currentColor" strokeLinecap="round"/>
  </svg>
);
const Plus = () => (
  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
    <path d="M6 2v8M2 6h8" stroke="currentColor" strokeLinecap="round"/>
  </svg>
);
const ArrowUp = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <path d="M6 2.5L10 8H2L6 2.5Z" fill="currentColor"/>
  </svg>
);
const CopyI = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <rect x="3.5" y="1.5" width="6" height="7" rx="1" stroke="currentColor"/>
    <path d="M2 4v6.5h6" stroke="currentColor" fill="none" strokeLinecap="round"/>
  </svg>
);

function ToolTag({ tool, taskType }) {
  return (
    <span className={`tool-tag tool-tag-${tool}`}>
      {TOOL_LABELS[tool]}
      <span style={{ opacity: 0.6, fontWeight: 300 }}>/ {taskType}</span>
    </span>
  );
}

function useLib() {
  const [view, setView] = useState("all"); // all | public | private | drafts
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("recent");
  const filtered = useMemo(() => {
    let r = MY_PROMPTS.filter(p => {
      if (view === "public" && !p.isPublic) return false;
      if (view === "private" && p.isPublic) return false;
      if (view === "drafts" && !p.title.toLowerCase().startsWith("wip")) return false;
      if (search && !p.title.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
    if (sort === "votes") r = [...r].sort((a, b) => b.upvoteCount - a.upvoteCount);
    if (sort === "copies") r = [...r].sort((a, b) => b.copyCount - a.copyCount);
    return r;
  }, [view, search, sort]);
  return { view, setView, search, setSearch, sort, setSort, filtered };
}

const stats = {
  total: MY_PROMPTS.length,
  public: MY_PROMPTS.filter(p => p.isPublic).length,
  private: MY_PROMPTS.filter(p => !p.isPublic).length,
  upvotes: MY_PROMPTS.reduce((s, p) => s + p.upvoteCount, 0),
  copies: MY_PROMPTS.reduce((s, p) => s + p.copyCount, 0),
};

/* ─── A. Dashboard with stats + filters + grid ─── */
function LibraryA() {
  const f = useLib();
  return (
    <div className="lib-shell">
      <header className="lib-header">
        <div>
          <span className="section-tag">Library</span>
          <h1 className="lib-h1">Your prompts</h1>
          <p className="lib-sub">Your private working library. Mark prompts public to share them on Explore.</p>
        </div>
        <button className="lib-btn-primary"><Plus /> New prompt</button>
      </header>

      <div className="lib-stats">
        <div className="lib-stat">
          <div className="lib-stat-n">{stats.total}</div>
          <div className="lib-stat-l">Prompts</div>
        </div>
        <div className="lib-stat">
          <div className="lib-stat-n" style={{ color: "var(--lp-accent)" }}>{stats.public}</div>
          <div className="lib-stat-l">Public</div>
        </div>
        <div className="lib-stat">
          <div className="lib-stat-n">{stats.private}</div>
          <div className="lib-stat-l">Private</div>
        </div>
        <div className="lib-stat">
          <div className="lib-stat-n">{stats.upvotes.toLocaleString()}</div>
          <div className="lib-stat-l">Upvotes received</div>
        </div>
        <div className="lib-stat">
          <div className="lib-stat-n">{stats.copies.toLocaleString()}</div>
          <div className="lib-stat-l">Times copied</div>
        </div>
      </div>

      <div className="lib-toolbar">
        <div className="lib-tabs">
          {[
            ["all", "All", stats.total],
            ["public", "Public", stats.public],
            ["private", "Private", stats.private],
            ["drafts", "Drafts", 1],
          ].map(([v, l, n]) => (
            <button key={v} className={`lib-tab ${f.view === v ? "active" : ""}`} onClick={() => f.setView(v)}>
              {l} <span className="lib-tab-n">{n}</span>
            </button>
          ))}
        </div>
        <div className="lib-tools-r">
          <div className="lib-search-wrap">
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <circle cx="6" cy="6" r="4" stroke="currentColor"/>
              <path d="M9.5 9.5L13 13" stroke="currentColor" strokeLinecap="round"/>
            </svg>
            <input placeholder="Search your prompts" value={f.search} onChange={e => f.setSearch(e.target.value)} />
          </div>
          <select className="ex-select" value={f.sort} onChange={e => f.setSort(e.target.value)}>
            <option value="recent">Recently edited</option>
            <option value="votes">Most upvoted</option>
            <option value="copies">Most copied</option>
          </select>
        </div>
      </div>

      <div className="lib-grid">
        {f.filtered.map(p => (
          <article key={p._id} className="lib-card">
            <div className="lib-card-head">
              <ToolTag tool={p.tool} taskType={p.taskType} />
              <span className={`lib-vis ${p.isPublic ? "public" : "private"}`} title={p.isPublic ? "Public" : "Private"}>
                {p.isPublic ? <Globe /> : <Lock />} {p.isPublic ? "Public" : "Private"}
              </span>
            </div>
            <h3 className="lib-card-title">{p.title}</h3>
            {p.description && <p className="lib-card-desc">{p.description}</p>}
            <div className="lib-card-stack">
              {p.stack.slice(0, 4).map(s => <span key={s} className="ex-stack-chip">{s}</span>)}
            </div>
            <footer className="lib-card-foot">
              <div className="lib-card-stats">
                {p.isPublic ? (
                  <>
                    <span><ArrowUp /> {p.upvoteCount.toLocaleString()}</span>
                    <span><CopyI /> {p.copyCount.toLocaleString()}</span>
                  </>
                ) : (
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 10.5, color: "var(--lp-text-dim)" }}>
                    edited {p.createdAt}
                  </span>
                )}
              </div>
              <div className="lib-card-actions">
                <button className="lib-icon-btn" title="Edit"><Pencil /></button>
                <button className="lib-icon-btn lib-danger" title="Delete"><Trash /></button>
              </div>
            </footer>
          </article>
        ))}
        <button className="lib-card lib-card-add">
          <div><Plus /></div>
          <div>New prompt</div>
        </button>
      </div>
    </div>
  );
}

/* ─── B. Two-column: Public vs Private ─── */
function LibraryB() {
  const pubs = MY_PROMPTS.filter(p => p.isPublic);
  const privs = MY_PROMPTS.filter(p => !p.isPublic);

  return (
    <div className="lib-shell">
      <header className="lib-header">
        <div>
          <span className="section-tag">Library</span>
          <h1 className="lib-h1">Your prompts</h1>
        </div>
        <button className="lib-btn-primary"><Plus /> New prompt</button>
      </header>

      <div className="lib-cols">
        <div className="lib-col">
          <div className="lib-col-head">
            <div className="lib-col-title"><Lock /> Private <span className="lib-col-n">{privs.length}</span></div>
            <span className="lib-col-meta">Only you can see these</span>
          </div>
          <div className="lib-col-list">
            {privs.map(p => (
              <div key={p._id} className="lib-row">
                <div className="lib-row-main">
                  <div className="lib-row-head">
                    <ToolTag tool={p.tool} taskType={p.taskType} />
                    <span className="lib-row-time">edited {p.createdAt}</span>
                  </div>
                  <h3 className="lib-row-title">{p.title}</h3>
                  {p.description && <p className="lib-row-desc">{p.description}</p>}
                </div>
                <div className="lib-row-actions">
                  <button className="lib-toggle"><Globe /> Make public</button>
                  <button className="lib-icon-btn"><Pencil /></button>
                  <button className="lib-icon-btn lib-danger"><Trash /></button>
                </div>
              </div>
            ))}
            <button className="lib-row lib-row-add">
              <Plus /> Add a private prompt
            </button>
          </div>
        </div>

        <div className="lib-col">
          <div className="lib-col-head">
            <div className="lib-col-title"><Globe /> Public <span className="lib-col-n">{pubs.length}</span></div>
            <span className="lib-col-meta">Shared on Explore</span>
          </div>
          <div className="lib-col-list">
            {pubs.map(p => (
              <div key={p._id} className="lib-row lib-row-public">
                <div className="lib-row-main">
                  <div className="lib-row-head">
                    <ToolTag tool={p.tool} taskType={p.taskType} />
                    <span className="lib-row-time">
                      <ArrowUp /> {p.upvoteCount.toLocaleString()} · <CopyI /> {p.copyCount.toLocaleString()}
                    </span>
                  </div>
                  <h3 className="lib-row-title">{p.title}</h3>
                  {p.description && <p className="lib-row-desc">{p.description}</p>}
                </div>
                <div className="lib-row-actions">
                  <button className="lib-toggle lib-toggle-on"><Lock /> Unpublish</button>
                  <button className="lib-icon-btn"><Pencil /></button>
                  <button className="lib-icon-btn lib-danger"><Trash /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── C. Dense list / table view ─── */
function LibraryC() {
  const f = useLib();
  return (
    <div className="lib-shell">
      <header className="lib-header">
        <div>
          <span className="section-tag">Library</span>
          <h1 className="lib-h1">Your prompts</h1>
          <p className="lib-sub">{stats.total} prompts · {stats.public} public · {stats.upvotes.toLocaleString()} upvotes received</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="lib-btn-secondary">Import .md</button>
          <button className="lib-btn-primary"><Plus /> New prompt</button>
        </div>
      </header>

      <div className="lib-toolbar">
        <div className="lib-tabs">
          {[
            ["all", "All", stats.total],
            ["public", "Public", stats.public],
            ["private", "Private", stats.private],
          ].map(([v, l, n]) => (
            <button key={v} className={`lib-tab ${f.view === v ? "active" : ""}`} onClick={() => f.setView(v)}>
              {l} <span className="lib-tab-n">{n}</span>
            </button>
          ))}
        </div>
        <div className="lib-tools-r">
          <div className="lib-search-wrap">
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <circle cx="6" cy="6" r="4" stroke="currentColor"/>
              <path d="M9.5 9.5L13 13" stroke="currentColor" strokeLinecap="round"/>
            </svg>
            <input placeholder="Search prompts" value={f.search} onChange={e => f.setSearch(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="lib-table">
        <div className="lib-table-head">
          <div className="lib-th lib-th-vis">Vis</div>
          <div className="lib-th lib-th-title">Title</div>
          <div className="lib-th lib-th-tool">Tool / Task</div>
          <div className="lib-th lib-th-stack">Stack</div>
          <div className="lib-th lib-th-stats">Upvotes</div>
          <div className="lib-th lib-th-stats">Copies</div>
          <div className="lib-th lib-th-date">Edited</div>
          <div className="lib-th lib-th-act"></div>
        </div>
        {f.filtered.map(p => (
          <div key={p._id} className="lib-tr">
            <div className="lib-th-vis" title={p.isPublic ? "Public" : "Private"}>
              <span className={`lib-vis-dot ${p.isPublic ? "public" : "private"}`}>
                {p.isPublic ? <Globe /> : <Lock />}
              </span>
            </div>
            <div className="lib-th-title">
              <div className="lib-tr-title">{p.title}</div>
              {p.description && <div className="lib-tr-desc">{p.description}</div>}
            </div>
            <div className="lib-th-tool"><ToolTag tool={p.tool} taskType={p.taskType} /></div>
            <div className="lib-th-stack">
              {p.stack.slice(0, 2).map(s => <span key={s} className="ex-stack-chip">{s}</span>)}
              {p.stack.length > 2 && <span className="ex-stack-more">+{p.stack.length - 2}</span>}
            </div>
            <div className="lib-th-stats">
              {p.isPublic ? <span className="lib-num"><ArrowUp /> {p.upvoteCount.toLocaleString()}</span> : <span className="lib-mute">—</span>}
            </div>
            <div className="lib-th-stats">
              {p.isPublic ? <span className="lib-num"><CopyI /> {p.copyCount.toLocaleString()}</span> : <span className="lib-mute">—</span>}
            </div>
            <div className="lib-th-date">{p.createdAt}</div>
            <div className="lib-th-act">
              <button className="lib-icon-btn"><Pencil /></button>
              <button className="lib-icon-btn lib-danger"><Trash /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.LibraryVariations = { LibraryA, LibraryB, LibraryC };
