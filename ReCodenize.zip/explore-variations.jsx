/* global React, ExploreData */
const { useState, useMemo } = React;
const { TOOL_LABELS, TOOLS, TASKS, SAMPLE_PROMPTS, STACKS } = ExploreData;

/* ─── Shared bits ─────────────────────────────────────── */

function ToolDot({ tool }) {
  const colors = {
    cursor: "var(--lp-red)",
    "claude-code": "var(--lp-blue)",
    copilot: "var(--lp-purple)",
    chatgpt: "var(--lp-accent)",
    aider: "oklch(72% 0.14 170)",
    other: "var(--lp-text-mid)",
  };
  return <span style={{
    width: 6, height: 6, borderRadius: "50%",
    background: colors[tool] || "var(--lp-text-mid)",
    display: "inline-block", flexShrink: 0,
  }} />;
}

function ToolTag({ tool, taskType }) {
  return (
    <span className={`tool-tag tool-tag-${tool}`}>
      {TOOL_LABELS[tool]}
      <span style={{ opacity: 0.6, fontWeight: 300 }}>/ {taskType}</span>
    </span>
  );
}

function Stat({ icon, value, label, onClick, active }) {
  return (
    <button
      className="ex-stat"
      onClick={onClick}
      style={{ color: active ? "var(--lp-accent)" : "var(--lp-text-dim)" }}
    >
      {icon}
      <span>{value.toLocaleString()}</span>
      {label && <span style={{ opacity: 0.7 }}>{label}</span>}
    </button>
  );
}

const ArrowUp = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <path d="M6 2.5L10 8H2L6 2.5Z" fill="currentColor"/>
  </svg>
);
const CopyIcon = () => (
  <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
    <rect x="3.5" y="1.5" width="6" height="7" rx="1" stroke="currentColor"/>
    <path d="M2 4v6.5h6" stroke="currentColor" fill="none" strokeLinecap="round"/>
  </svg>
);
const SparkleIcon = () => (
  <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
    <path d="M6 1L7 5L11 6L7 7L6 11L5 7L1 6L5 5L6 1Z" fill="currentColor"/>
  </svg>
);

/* ─── PromptCard — denser, with stack chips, copy + vote ── */

function PromptCard({ prompt, density = "medium", showAuthor = true }) {
  const [voted, setVoted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [votes, setVotes] = useState(prompt.upvoteCount);

  function handleVote(e) {
    e.stopPropagation();
    setVoted(v => !v);
    setVotes(v => voted ? v - 1 : v + 1);
  }
  function handleCopy(e) {
    e.stopPropagation();
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  }

  const isCompact = density === "compact";

  return (
    <article className="ex-card">
      <div className="ex-card-head">
        <ToolTag tool={prompt.tool} taskType={prompt.taskType} />
        {prompt.featured && (
          <span className="ex-featured-pill"><SparkleIcon /> Featured</span>
        )}
      </div>

      <h3 className="ex-card-title">{prompt.title}</h3>

      {prompt.description && !isCompact && (
        <p className="ex-card-desc">{prompt.description}</p>
      )}

      {!isCompact && (
        <pre className="ex-card-body">{prompt.body}</pre>
      )}

      <div className="ex-card-meta">
        <div className="ex-stack">
          {prompt.stack.slice(0, 3).map(s => (
            <span key={s} className="ex-stack-chip">{s}</span>
          ))}
          {prompt.stack.length > 3 && (
            <span className="ex-stack-more">+{prompt.stack.length - 3}</span>
          )}
        </div>
      </div>

      <footer className="ex-card-foot">
        {showAuthor && (
          <div className="ex-author">
            <span className="ex-avatar" style={{ background: prompt.author.color }}>
              {prompt.author.initial}
            </span>
            <span className="ex-author-name">{prompt.author.name}</span>
            <span className="ex-author-time">· {prompt.createdAt}</span>
          </div>
        )}
        <div className="ex-actions">
          <button className={`ex-vote ${voted ? "voted" : ""}`} onClick={handleVote} title="Upvote">
            <ArrowUp />
            <span>{votes.toLocaleString()}</span>
          </button>
          <button className="ex-copy" onClick={handleCopy} title="Copy prompt">
            <CopyIcon />
            <span>{copied ? "copied" : prompt.copyCount.toLocaleString()}</span>
          </button>
        </div>
      </footer>
    </article>
  );
}

/* ─── PromptRow — list/dense view ─────────────────────── */

function PromptRow({ prompt }) {
  const [voted, setVoted] = useState(false);
  const [votes, setVotes] = useState(prompt.upvoteCount);

  function handleVote(e) {
    e.stopPropagation();
    setVoted(v => !v);
    setVotes(v => voted ? v - 1 : v + 1);
  }

  return (
    <div className="ex-row">
      <button className={`ex-row-vote ${voted ? "voted" : ""}`} onClick={handleVote}>
        <ArrowUp />
        <span>{votes.toLocaleString()}</span>
      </button>
      <div className="ex-row-main">
        <div className="ex-row-head">
          <h3 className="ex-row-title">{prompt.title}</h3>
          {prompt.featured && <span className="ex-featured-pill"><SparkleIcon /> Featured</span>}
        </div>
        {prompt.description && <p className="ex-row-desc">{prompt.description}</p>}
        <div className="ex-row-meta">
          <ToolTag tool={prompt.tool} taskType={prompt.taskType} />
          <span className="ex-row-sep">·</span>
          <div className="ex-stack">
            {prompt.stack.slice(0, 3).map(s => (
              <span key={s} className="ex-stack-chip">{s}</span>
            ))}
          </div>
          <span className="ex-row-sep">·</span>
          <span className="ex-row-author">
            <span className="ex-avatar-sm" style={{ background: prompt.author.color }}>{prompt.author.initial}</span>
            {prompt.author.name} · {prompt.createdAt}
          </span>
        </div>
      </div>
      <div className="ex-row-actions">
        <button className="ex-icon-btn" title="Copy"><CopyIcon /></button>
        <button className="ex-icon-btn" title="Fork">
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
            <circle cx="3" cy="3" r="1.5" stroke="currentColor"/>
            <circle cx="9" cy="3" r="1.5" stroke="currentColor"/>
            <circle cx="6" cy="10" r="1.5" stroke="currentColor"/>
            <path d="M3 4.5v1.5h6V4.5M6 6.5V8.5" stroke="currentColor" fill="none"/>
          </svg>
        </button>
      </div>
    </div>
  );
}

/* ─── useFilters helper ───────────────────────────────── */

function useFilters() {
  const [tool, setTool] = useState("all");
  const [task, setTask] = useState("all");
  const [search, setSearch] = useState("");
  const [stacks, setStacks] = useState([]);
  const [sort, setSort] = useState("top");

  const filtered = useMemo(() => {
    let r = SAMPLE_PROMPTS.filter(p => {
      if (tool !== "all" && p.tool !== tool) return false;
      if (task !== "all" && p.taskType !== task) return false;
      if (stacks.length && !stacks.some(s => p.stack.includes(s))) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!p.title.toLowerCase().includes(q) &&
            !p.body.toLowerCase().includes(q) &&
            !(p.description || "").toLowerCase().includes(q)) return false;
      }
      return true;
    });
    if (sort === "top") r = [...r].sort((a, b) => b.upvoteCount - a.upvoteCount);
    if (sort === "new") r = [...r].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    if (sort === "copied") r = [...r].sort((a, b) => b.copyCount - a.copyCount);
    return r;
  }, [tool, task, search, stacks, sort]);

  function toggleStack(s) {
    setStacks(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  }
  function reset() {
    setTool("all"); setTask("all"); setSearch(""); setStacks([]);
  }
  const active = tool !== "all" || task !== "all" || search !== "" || stacks.length > 0;

  return {
    tool, setTool, task, setTask, search, setSearch,
    stacks, toggleStack, sort, setSort,
    filtered, reset, active,
  };
}

/* ─── A. Refined top-filters ──────────────────────────── */

function ExploreA() {
  const f = useFilters();
  const featured = SAMPLE_PROMPTS.filter(p => p.featured);

  return (
    <div className="ex-shell">
      <header className="ex-header">
        <div>
          <span className="section-tag">Explore</span>
          <h1 className="ex-h1">Community prompts</h1>
        </div>
        <div className="ex-header-stats">
          <span><b>{SAMPLE_PROMPTS.length}</b> prompts</span>
          <span className="ex-row-sep">·</span>
          <span><b>{SAMPLE_PROMPTS.reduce((s, p) => s + p.copyCount, 0).toLocaleString()}</b> copies</span>
          <span className="ex-row-sep">·</span>
          <span>updated <b>just now</b></span>
        </div>
      </header>

      <div className="ex-toolbar">
        <div className="ex-search-wrap">
          <svg className="ex-search-icon" width="14" height="14" viewBox="0 0 14 14" fill="none">
            <circle cx="6" cy="6" r="4" stroke="currentColor"/>
            <path d="M9.5 9.5L13 13" stroke="currentColor" strokeLinecap="round"/>
          </svg>
          <input
            className="ex-search"
            placeholder="Search titles, bodies, descriptions…"
            value={f.search}
            onChange={e => f.setSearch(e.target.value)}
          />
          {f.search && (
            <button className="ex-search-clear" onClick={() => f.setSearch("")}>×</button>
          )}
        </div>
        <div className="ex-toolbar-right">
          <label className="ex-select-label">
            Tool
            <select className="ex-select" value={f.tool} onChange={e => f.setTool(e.target.value)}>
              {TOOLS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </label>
          <label className="ex-select-label">
            Task
            <select className="ex-select" value={f.task} onChange={e => f.setTask(e.target.value)}>
              {TASKS.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </label>
          <label className="ex-select-label">
            Sort
            <select className="ex-select" value={f.sort} onChange={e => f.setSort(e.target.value)}>
              <option value="top">Top all-time</option>
              <option value="new">Newest</option>
              <option value="copied">Most copied</option>
            </select>
          </label>
        </div>
      </div>

      <div className="ex-stack-row">
        <span className="ex-stack-label">Stack</span>
        {STACKS.map(s => (
          <button
            key={s}
            className={`lp-chip ${f.stacks.includes(s) ? "active" : ""}`}
            onClick={() => f.toggleStack(s)}
          >
            {s}
          </button>
        ))}
        {f.active && (
          <button className="ex-clear-link" onClick={f.reset}>Clear filters ×</button>
        )}
      </div>

      {!f.active && featured.length > 0 && (
        <div className="ex-featured-row">
          <div className="ex-featured-head">
            <SparkleIcon /> <span>Featured this week</span>
          </div>
          <div className="ex-featured-grid">
            {featured.map(p => <PromptCard key={p._id} prompt={p} />)}
          </div>
        </div>
      )}

      <div className="ex-results-head">
        <span><b>{f.filtered.length}</b> {f.filtered.length === 1 ? "result" : "results"}</span>
        {f.active && <span className="ex-active-summary">
          {f.tool !== "all" && <span className="ex-active-chip">{TOOL_LABELS[f.tool]} <em onClick={() => f.setTool("all")}>×</em></span>}
          {f.task !== "all" && <span className="ex-active-chip">{f.task} <em onClick={() => f.setTask("all")}>×</em></span>}
          {f.stacks.map(s => <span key={s} className="ex-active-chip">{s} <em onClick={() => f.toggleStack(s)}>×</em></span>)}
          {f.search && <span className="ex-active-chip">"{f.search}" <em onClick={() => f.setSearch("")}>×</em></span>}
        </span>}
      </div>

      {f.filtered.length === 0 ? (
        <div className="ex-empty">
          <div className="ex-empty-icon">∅</div>
          <h3>No prompts match these filters.</h3>
          <p>Try removing a filter, or be the first to post one for this combination.</p>
          <div className="ex-empty-actions">
            <button className="ex-btn-secondary" onClick={f.reset}>Clear filters</button>
            <button className="ex-btn-primary">+ Post a prompt</button>
          </div>
        </div>
      ) : (
        <div className="ex-grid-3">
          {f.filtered.map(p => <PromptCard key={p._id} prompt={p} />)}
        </div>
      )}
    </div>
  );
}

/* ─── B. Sidebar layout (Linear-style) ────────────────── */

function ExploreB() {
  const f = useFilters();
  const counts = useMemo(() => {
    const byTool = {}; const byTask = {};
    SAMPLE_PROMPTS.forEach(p => {
      byTool[p.tool] = (byTool[p.tool] || 0) + 1;
      byTask[p.taskType] = (byTask[p.taskType] || 0) + 1;
    });
    return { byTool, byTask };
  }, []);

  return (
    <div className="ex-shell-sidebar">
      <aside className="ex-sidebar">
        <div className="ex-side-section">
          <div className="ex-side-search">
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none">
              <circle cx="6" cy="6" r="4" stroke="currentColor"/>
              <path d="M9.5 9.5L13 13" stroke="currentColor" strokeLinecap="round"/>
            </svg>
            <input
              placeholder="Search prompts"
              value={f.search}
              onChange={e => f.setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="ex-side-section">
          <div className="ex-side-h">Tool</div>
          <button className={`ex-side-item ${f.tool === "all" ? "active" : ""}`} onClick={() => f.setTool("all")}>
            <span>All tools</span>
            <span className="ex-side-count">{SAMPLE_PROMPTS.length}</span>
          </button>
          {TOOLS.slice(1).map(t => (
            <button key={t.value} className={`ex-side-item ${f.tool === t.value ? "active" : ""}`} onClick={() => f.setTool(t.value)}>
              <span style={{display: "flex", alignItems: "center", gap: 8}}>
                <ToolDot tool={t.value} /> {t.label}
              </span>
              <span className="ex-side-count">{counts.byTool[t.value] || 0}</span>
            </button>
          ))}
        </div>

        <div className="ex-side-section">
          <div className="ex-side-h">Task type</div>
          <button className={`ex-side-item ${f.task === "all" ? "active" : ""}`} onClick={() => f.setTask("all")}>
            <span>Any task</span>
            <span className="ex-side-count">{SAMPLE_PROMPTS.length}</span>
          </button>
          {TASKS.slice(1).map(t => (
            <button key={t.value} className={`ex-side-item ${f.task === t.value ? "active" : ""}`} onClick={() => f.setTask(t.value)}>
              <span style={{textTransform: "capitalize"}}>{t.label}</span>
              <span className="ex-side-count">{counts.byTask[t.value] || 0}</span>
            </button>
          ))}
        </div>

        <div className="ex-side-section">
          <div className="ex-side-h">Stack</div>
          <div className="ex-side-chips">
            {STACKS.slice(0, 8).map(s => (
              <button key={s}
                className={`lp-chip ${f.stacks.includes(s) ? "active" : ""}`}
                onClick={() => f.toggleStack(s)}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {f.active && (
          <button className="ex-side-clear" onClick={f.reset}>Clear all filters</button>
        )}
      </aside>

      <div className="ex-main">
        <header className="ex-main-head">
          <div>
            <h1 className="ex-h1-sm">Community prompts</h1>
            <p className="ex-main-sub">
              {f.filtered.length} {f.filtered.length === 1 ? "result" : "results"}
              {f.active && " for your filters"}
            </p>
          </div>
          <div className="ex-segmented">
            {["top", "new", "copied"].map(s => (
              <button key={s}
                className={`ex-seg ${f.sort === s ? "active" : ""}`}
                onClick={() => f.setSort(s)}>
                {s === "top" ? "Top" : s === "new" ? "New" : "Most copied"}
              </button>
            ))}
          </div>
        </header>

        {f.filtered.length === 0 ? (
          <div className="ex-empty">
            <div className="ex-empty-icon">∅</div>
            <h3>No prompts match these filters.</h3>
            <button className="ex-btn-secondary" onClick={f.reset}>Clear filters</button>
          </div>
        ) : (
          <div className="ex-list">
            {f.filtered.map(p => <PromptRow key={p._id} prompt={p} />)}
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── C. Featured-led discovery view ──────────────────── */

function ExploreC() {
  const f = useFilters();
  const trending = SAMPLE_PROMPTS.slice(0, 3);
  const rest = f.filtered.filter(p => !trending.includes(p));

  return (
    <div className="ex-shell">
      <header className="ex-header-c">
        <span className="section-tag">Explore · Curated</span>
        <h1 className="ex-h1-c">Prompts that <em>actually</em> ship code.</h1>
        <p className="ex-main-sub" style={{ maxWidth: 520, marginTop: 8 }}>
          Hand-picked from the community library. Sorted by what people copy, not by what they upvote.
        </p>
      </header>

      <div className="ex-trending">
        <div className="ex-trending-head">
          <SparkleIcon />
          <span>Trending this week</span>
        </div>
        <div className="ex-hero-grid">
          <div className="ex-hero-feature">
            <PromptCard prompt={trending[0]} />
          </div>
          <div className="ex-hero-stack">
            {trending.slice(1).map(p => (
              <PromptRow key={p._id} prompt={p} />
            ))}
          </div>
        </div>
      </div>

      <div className="ex-toolbar ex-toolbar-tight">
        <div className="ex-search-wrap">
          <svg className="ex-search-icon" width="14" height="14" viewBox="0 0 14 14" fill="none">
            <circle cx="6" cy="6" r="4" stroke="currentColor"/>
            <path d="M9.5 9.5L13 13" stroke="currentColor" strokeLinecap="round"/>
          </svg>
          <input
            className="ex-search"
            placeholder="Search the library…"
            value={f.search}
            onChange={e => f.setSearch(e.target.value)}
          />
        </div>
        <div className="ex-segmented">
          {["top", "new", "copied"].map(s => (
            <button key={s}
              className={`ex-seg ${f.sort === s ? "active" : ""}`}
              onClick={() => f.setSort(s)}>
              {s === "top" ? "Top" : s === "new" ? "New" : "Most copied"}
            </button>
          ))}
        </div>
      </div>

      <div className="ex-chip-row">
        {TOOLS.map(t => (
          <button key={t.value}
            className={`lp-chip ${f.tool === t.value ? "active" : ""}`}
            onClick={() => f.setTool(t.value)}>
            {t.value !== "all" && <ToolDot tool={t.value} />}
            <span style={{ marginLeft: t.value !== "all" ? 6 : 0 }}>{t.label}</span>
          </button>
        ))}
      </div>

      <div className="ex-results-head">
        <span><b>All prompts</b> · {f.filtered.length} {f.filtered.length === 1 ? "result" : "results"}</span>
      </div>

      <div className="ex-grid-2">
        {rest.map(p => <PromptCard key={p._id} prompt={p} />)}
      </div>
    </div>
  );
}

window.ExploreVariations = { ExploreA, ExploreB, ExploreC };
