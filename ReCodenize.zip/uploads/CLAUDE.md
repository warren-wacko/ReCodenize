# ReCodenize — Product Requirements Document (MERN + TypeScript)

> Save this file as `CLAUDE.md` in your project root. Claude Code reads it automatically as context for every prompt in this repo.

---

## 1. Project Context

**ReCodenize** is a library and social feed for AI coding prompts, rules, and context snippets — the things that actually make Cursor, Claude Code, Copilot, and ChatGPT produce good code.

**The story:** ReCodenize started in 2020 as a code snippet manager. Devs don't write boilerplate by hand anymore — AI generates it on demand. But every dev now has a hidden personal library of prompts, rules files, and context blocks that they reuse constantly, scattered across Notion, random `.md` files, and screenshots. ReCodenize is rebuilt for that.

**Tagline:** *The library for how you code with AI.*

**Build constraint:** This is a **2-day MVP**. Scope discipline is the most important thing. Anything in §11 (Non-Goals) is not built this weekend, no matter how tempting.

---

## 2. Goals

1. A logged-in user can save, edit, and delete prompts in their personal library.
2. A user can mark a prompt public; public prompts appear in an Explore feed.
3. Other users can browse the Explore feed, filter by tool/stack/task, copy any prompt to clipboard, and upvote it.
4. Each prompt has a shareable public URL.
5. A logged-in user can "fork" a public prompt into their own library.
6. The app is deployed to a public URL by end of Day 2.
7. The Explore feed is seeded with 30–50 high-quality prompts before launch (an empty feed kills the project).

---

## 3. Target Users

- Devs using Cursor, Claude Code, Copilot, ChatGPT, or Aider daily.
- Distribution channels: r/ChatGPTCoding, r/cursor, r/ClaudeAI, Hacker News, Indie Hackers, dev Twitter.

---

## 4. Tech Stack

### Frontend (`client/`)
| Layer | Choice |
|---|---|
| Build tool | **Vite** + React 18 + TypeScript |
| Routing | React Router v6 |
| Client state | **Zustand** (auth user, filters, UI state) |
| Server state | **TanStack Query (React Query) v5** (prompts data, mutations) |
| Styling | Tailwind CSS + shadcn/ui |
| Forms | react-hook-form + zod |
| HTTP | `fetch` wrapped in a thin `api.ts` client (`credentials: 'include'`) |

### Backend (`server/`)
| Layer | Choice |
|---|---|
| Runtime | Node.js 20 + TypeScript |
| Framework | Express 4 |
| ORM | Mongoose 8 |
| Auth | Google Identity Services (frontend) → ID token verified server-side via `google-auth-library` → JWT in httpOnly cookie |
| Validation | zod |
| Logging | `pino` (or `morgan` if you're in a hurry) |

### Infrastructure
| Layer | Choice |
|---|---|
| Database | MongoDB Atlas (free tier, 512MB) |
| Frontend hosting | Vercel |
| Backend hosting | Render (free tier — cold starts OK for MVP) or Railway |

### Why Zustand AND TanStack Query?

Zustand is great for **client state** (the logged-in user object, current filter chips, modal open/closed). It's bad for **server state** (lists of prompts, single prompt fetches) because you'd have to hand-roll caching, refetching, optimistic updates, and invalidation — that's a week of work poorly done.

TanStack Query handles all of that with two hooks (`useQuery`, `useMutation`). The split is the modern React best practice and it'll save you hours this weekend.

If you really want Zustand-only, you can — but expect to write more code and have more bugs. Recommendation: use both, scoped strictly as in §8.

Do **not** add: Redux, Redux Toolkit, MobX, Recoil, Jotai, GraphQL, tRPC, Prisma, NestJS, custom auth schemes, email/password, or any new tool you haven't used before.

---

## 5. Repo Structure

A simple two-folder layout — no monorepo tooling needed.

```
recodenize/
├── CLAUDE.md                # this file
├── README.md
├── client/                  # Vite + React + TS
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── routes/
│   │   │   ├── Landing.tsx
│   │   │   ├── Login.tsx
│   │   │   ├── Library.tsx
│   │   │   ├── PromptNew.tsx
│   │   │   ├── PromptEdit.tsx
│   │   │   ├── Explore.tsx
│   │   │   └── PromptDetail.tsx
│   │   ├── components/
│   │   │   ├── ui/                # shadcn
│   │   │   ├── PromptCard.tsx
│   │   │   ├── PromptForm.tsx
│   │   │   ├── TagFilter.tsx
│   │   │   ├── CopyButton.tsx
│   │   │   ├── VoteButton.tsx
│   │   │   └── RequireAuth.tsx
│   │   ├── stores/
│   │   │   ├── auth.ts            # Zustand
│   │   │   ├── filters.ts         # Zustand
│   │   │   └── ui.ts              # Zustand
│   │   ├── hooks/
│   │   │   ├── usePrompts.ts      # TanStack Query
│   │   │   ├── usePrompt.ts
│   │   │   ├── useCreatePrompt.ts
│   │   │   ├── useUpdatePrompt.ts
│   │   │   ├── useDeletePrompt.ts
│   │   │   ├── useVote.ts
│   │   │   └── useFork.ts
│   │   ├── lib/
│   │   │   ├── api.ts             # fetch wrapper
│   │   │   ├── types.ts           # shared types
│   │   │   └── utils.ts           # cn()
│   │   └── index.css
│   ├── index.html
│   ├── tailwind.config.ts
│   ├── vite.config.ts
│   ├── tsconfig.json
│   └── package.json
└── server/                  # Express + TS
    ├── src/
    │   ├── index.ts               # entrypoint
    │   ├── app.ts                 # express app config
    │   ├── config/
    │   │   ├── env.ts             # zod-validated env
    │   │   └── db.ts              # mongoose connect
    │   ├── models/
    │   │   ├── User.ts
    │   │   ├── Prompt.ts
    │   │   └── Vote.ts
    │   ├── routes/
    │   │   ├── auth.routes.ts
    │   │   └── prompts.routes.ts
    │   ├── controllers/
    │   │   ├── auth.controller.ts
    │   │   └── prompts.controller.ts
    │   ├── middleware/
    │   │   ├── requireAuth.ts
    │   │   ├── errorHandler.ts
    │   │   └── validate.ts        # zod middleware
    │   ├── lib/
    │   │   ├── jwt.ts
    │   │   └── google.ts          # verify Google ID token
    │   └── scripts/
    │       └── seed.ts            # seed Explore feed
    ├── tsconfig.json
    └── package.json
```

---

## 6. Database Schema (Mongoose)

### `User`
```ts
{
  _id: ObjectId,
  googleId: string,        // unique, indexed
  email: string,           // unique, indexed
  name: string,
  avatarUrl: string,
  createdAt: Date,
  updatedAt: Date,
}
```

### `Prompt`
```ts
{
  _id: ObjectId,
  userId: ObjectId,        // ref 'User', indexed
  title: string,
  body: string,
  description?: string,    // "why this works" / when to use
  tool: 'cursor' | 'claude-code' | 'copilot' | 'chatgpt' | 'aider' | 'other',
  taskType: 'refactor' | 'scaffold' | 'debug' | 'test' | 'review' | 'explain' | 'rules' | 'other',
  stack: string[],         // e.g. ['nextjs', 'typescript', 'tailwind']
  isPublic: boolean,       // default false
  upvoteCount: number,     // denormalized, default 0
  copyCount: number,       // default 0
  createdAt: Date,
  updatedAt: Date,
}
```
**Indexes:**
- `{ userId: 1, createdAt: -1 }` — personal library queries
- `{ isPublic: 1, upvoteCount: -1 }` — Explore feed sort
- `{ tool: 1, isPublic: 1 }` — Explore filter

### `Vote`
```ts
{
  _id: ObjectId,
  userId: ObjectId,
  promptId: ObjectId,
  createdAt: Date,
}
```
**Indexes:**
- `{ userId: 1, promptId: 1 }` — **unique compound index** (prevents double-voting)
- `{ promptId: 1 }`

---

## 7. API Routes (Express)

All `/api/prompts/*` write routes require a valid JWT cookie. Reads on public prompts do not.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | `/api/auth/google` | — | Body: `{ idToken }`. Verify with Google, upsert User, set JWT cookie. |
| POST | `/api/auth/logout` | ✓ | Clear JWT cookie. |
| GET | `/api/auth/me` | ✓ | Return current user. |
| GET | `/api/prompts/me` | ✓ | Current user's prompts (paginated). |
| POST | `/api/prompts` | ✓ | Create. |
| GET | `/api/prompts/explore` | — | Public feed. Query: `tool`, `taskType`, `stack`, `q` (search), `cursor`, `limit`. |
| GET | `/api/prompts/:id` | — | Single prompt. 404 if private and not owner. |
| PATCH | `/api/prompts/:id` | ✓ | Update. Owner only. |
| DELETE | `/api/prompts/:id` | ✓ | Delete. Owner only. |
| POST | `/api/prompts/:id/vote` | ✓ | Toggle vote. Returns `{ voted: boolean, upvoteCount: number }`. |
| POST | `/api/prompts/:id/copy` | — | Increment `copyCount`. Returns `{ copyCount }`. |
| POST | `/api/prompts/:id/fork` | ✓ | Duplicate the prompt into the requester's library as private. |

**Vote toggling logic:** in a single transaction, try to insert into `votes`; on duplicate-key error, delete instead. Then `Prompt.updateOne({ _id }, { $inc: { upvoteCount: ±1 } })`.

**Validation:** every request body parsed through a zod schema in `middleware/validate.ts`. Reject with 400 + zod errors.

---

## 8. State Management — Strict Split

### Zustand (client state only)

```ts
// stores/auth.ts
type AuthState = {
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => Promise<void>;
};

// stores/filters.ts  (drives /explore query params)
type FiltersState = {
  tool: Tool | 'all';
  taskType: TaskType | 'all';
  stack: string[];
  search: string;
  setTool: (t: Tool | 'all') => void;
  setTaskType: (t: TaskType | 'all') => void;
  toggleStack: (s: string) => void;
  setSearch: (q: string) => void;
  reset: () => void;
};

// stores/ui.ts  (modals, toasts, etc — only if needed)
```

### TanStack Query (server state only)

Every prompt fetch and mutation goes through a hook in `client/src/hooks/`. Query keys:

- `['prompts', 'me']`
- `['prompts', 'explore', filters]`
- `['prompt', id]`

Mutations invalidate the relevant keys. Use `onMutate` for optimistic updates on vote and copy buttons.

**Rule:** Zustand stores never hold prompt data. TanStack Query never holds the auth user. Don't blur the line.

---

## 9. Auth Flow (Google ID Token → JWT Cookie)

This is the part that eats time if you wing it. Follow exactly:

1. Frontend loads Google Identity Services script (`https://accounts.google.com/gsi/client`).
2. User clicks the rendered Google button → Google returns an `idToken` (JWT signed by Google).
3. Frontend POSTs `idToken` to `/api/auth/google`.
4. Backend verifies with `google-auth-library`:
   ```ts
   const ticket = await client.verifyIdToken({ idToken, audience: GOOGLE_CLIENT_ID });
   const { sub, email, name, picture } = ticket.getPayload()!;
   ```
5. Backend upserts the User by `googleId: sub`.
6. Backend signs its own JWT (`jsonwebtoken`, 7-day expiry, payload = `{ userId }`) and sets it as an httpOnly cookie.
7. Frontend calls `GET /api/auth/me` → Zustand `setUser`.

### Cross-origin cookie config (THE GOTCHA)

Frontend on `https://recodenize.vercel.app`, backend on `https://recodenize-api.onrender.com` — different origins. For cookies to work:

**Backend:**
```ts
app.use(cors({
  origin: process.env.CLIENT_URL,    // exact origin, NOT '*'
  credentials: true,
}));

res.cookie('token', jwt, {
  httpOnly: true,
  secure: true,            // required when sameSite='none'
  sameSite: 'none',        // required for cross-origin
  maxAge: 7 * 24 * 60 * 60 * 1000,
});
```

**Frontend `lib/api.ts`:**
```ts
fetch(url, { credentials: 'include', ... })
```

In dev (both on localhost), use `sameSite: 'lax'` and `secure: false`. Branch on `NODE_ENV`.

---

## 10. Day-by-Day Plan

### Day 1 (~10 hours)

- **H1:** `pnpm create vite client --template react-ts`. Init `server/` with Express + TS (`tsx` for dev, `tsc` for build). MongoDB Atlas cluster + connection string. Both `npm run dev` boot cleanly.
- **H2:** Tailwind + shadcn in client. React Router routes scaffolded (empty pages). Express CORS + cookie-parser. Health check `GET /api/health` returns 200 from frontend.
- **H3–4:** Auth end-to-end. Google Cloud Console OAuth client. `User` model. `/api/auth/google`, `/api/auth/me`, `/api/auth/logout`. `useAuthStore`. `RequireAuth` guard component. Round trip: click Google button → cookie set → `/library` accessible.
- **H5–6:** `Prompt` model. `POST /api/prompts`, `GET /api/prompts/me`, `PATCH`, `DELETE`. `usePrompts` and `useCreatePrompt` hooks. `PromptForm` component (react-hook-form + zod). `Library` page renders the user's prompts.
- **H7–8:** Public/private toggle on the form. `Vote` model. `GET /api/prompts/explore` with filter query params. `Explore` page uses `useFiltersStore` + `usePrompts({ filters })`. `TagFilter` component.
- **H9–10:** `CopyButton` (clipboard API + `POST .../copy`). `VoteButton` with optimistic update via TanStack `onMutate`. `PromptDetail` page at `/p/:id`.

**Day 1 done = end-to-end usable, even if rough.**

### Day 2 (~10 hours)

- **H1–3:** Polish. Empty states, loading skeletons, error toasts (sonner). Mobile layout (test on phone). Replace placeholder landing with the real one — rebuild story, screenshots, "Sign in with Google" CTA.
- **H4–5:** Fork feature. `POST /api/prompts/:id/fork` + `useFork` hook + button on `PromptDetail`. Copy count badge on cards. Search input wired to `useFiltersStore.search`.
- **H6–7:** **Seed `server/src/scripts/seed.ts` with 30–50 prompts** across all tools and task types. Pull from your own usage and inspiration from r/ChatGPTCoding top posts (rewrite in your own words). Run against prod DB before launch.
- **H8:** Deploy. Vercel for client (set `VITE_API_URL`). Render for server (set all env vars, including `CLIENT_URL`). MongoDB Atlas IP allowlist set to `0.0.0.0/0` for Render. Test sign-in on prod.
- **H9–10:** Open Graph image (`client/public/og.png` + meta tags). 30-second screen recording. Draft launch posts. Schedule for Monday morning.

---

## 11. Non-Goals (do NOT build this weekend)

These are tempting and they will eat your weekend. Build them in week 2+.

- ❌ Browser extension
- ❌ CLI tool
- ❌ MCP server / Claude Code integration
- ❌ Outcome tracking (did the prompt work?)
- ❌ Workflow chains (multi-step prompts)
- ❌ Variable/placeholder interpolation (`{{file}}`)
- ❌ Email/password auth (Google only)
- ❌ Comments
- ❌ Following/feeds per user
- ❌ Premium / paid prompts
- ❌ Teams / orgs
- ❌ Versioning of prompts
- ❌ AI features (semantic search, auto-tagging) — Mongo `$regex` is fine for now
- ❌ Real-time updates (WebSockets / SSE)
- ❌ Tests (yes, really — for a 2-day MVP, skip them and add later)

When Claude Code suggests any of the above, decline and stay on scope.

---

## 12. Coding Conventions

### Both
- **TypeScript strict mode.** No `any` unless commented `// TODO: type`.
- **zod everywhere data crosses a boundary.** API request bodies, env vars, responses if you want.
- **Conventional commits** (`feat:`, `fix:`, `chore:`).
- **Shared types** live in `client/src/lib/types.ts` for now; if you find yourself copy-pasting, lift to a `shared/` folder later.

### Frontend
- **Functional components only.** Hooks for everything.
- **No `useEffect` for data fetching.** Use TanStack Query.
- **Forms:** react-hook-form + zod resolver. No uncontrolled inputs except trivial ones.
- **Styling:** Tailwind utility classes. `cn()` helper from `lib/utils.ts`.
- **shadcn:** install via `pnpm dlx shadcn@latest add <component>`. Don't modify in place; wrap.
- **Toasts:** `sonner` (shadcn-recommended). No `alert()`.
- **Errors:** thrown by `api.ts` as `ApiError`, caught by TanStack Query's `onError` → toast.

### Backend
- **Controllers stay thin.** Validate → call service-ish helper → respond.
- **One try/catch in `errorHandler` middleware.** Controllers throw; middleware formats.
- **Mongoose:** use `.lean()` on reads that don't need methods. Always `select` only what's needed.
- **Never trust the client.** Re-check ownership inside PATCH/DELETE/fork handlers.

### What not to abstract yet
- Don't build a "Repository" layer over Mongoose.
- Don't build a "Service" layer until controllers exceed ~30 lines.
- Don't build a custom hook for every fetch — TanStack Query hooks are enough.
- Inline duplication is fine until 3+ uses.

---

## 13. Environment Variables

### `client/.env`
```bash
VITE_API_URL=http://localhost:4000
VITE_GOOGLE_CLIENT_ID=
```

### `server/.env`
```bash
NODE_ENV=development
PORT=4000
MONGODB_URI=
JWT_SECRET=                # 32+ random chars
GOOGLE_CLIENT_ID=          # same as VITE_GOOGLE_CLIENT_ID
CLIENT_URL=http://localhost:5173
```

Validate on boot in `server/src/config/env.ts` with zod — fail fast if anything's missing.

---

## 14. Success Criteria

By end of Day 2:

- [ ] Frontend deployed to Vercel, backend to Render, DB on Atlas.
- [ ] I can sign in with Google in incognito (cross-origin cookies working).
- [ ] I can create, edit, delete a prompt.
- [ ] I can mark a prompt public and see it on `/explore`.
- [ ] A logged-out user can browse `/explore`, click a prompt, and copy it.
- [ ] A logged-in user can upvote and fork a public prompt.
- [ ] Filters and search on `/explore` work and persist via URL params.
- [ ] Explore feed has 30+ seeded prompts.
- [ ] Mobile layout looks fine on actual phone.
- [ ] OG preview is clean when pasted in Twitter/Reddit.

---

## 15. Launch Plan (Monday)

Post in this order, **spaced 2–3 hours apart**:

1. **r/ChatGPTCoding** — title: *"I built a snippet manager in 2020. Devs don't write snippets anymore, so I rebuilt it for AI prompts."* (lead with the rebuild story)
2. **Hacker News** — Show HN: ReCodenize – A library for the prompts and rules you reuse with AI coding tools
3. **Indie Hackers** — milestone post
4. **Twitter/X** — 30-second screen recording, same rebuild-story framing
5. **r/cursor** and **r/ClaudeAI** later in the day if the first posts gain traction

The rebuild narrative is the hook. Lead with it everywhere.
